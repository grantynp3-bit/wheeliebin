# Wheelie Bin Reminder (Newport City Council)

A tiny Android app that checks Newport City Council's bin collection system in the
background and sends you a notification when a bin is due for collection tomorrow.
No account, no server, no subscription — your UPRN is stored only on your phone.

## How it works

- Newport's "check your collection day" tool is powered by a system called
  iTouchVision. This app talks to that same system directly using your **UPRN**
  (Unique Property Reference Number) — a 12-digit code every UK address has.
- A background job (Android WorkManager) checks a few times a day. If a bin is due
  **tomorrow** and you haven't already been notified for that date, it shows a
  notification.
- Because it's a background check rather than an exact-time alarm, the notification
  can arrive up to a few hours after Android decides to run the check — usually
  it's much sooner. There's no server involved, so there's nothing to keep paying for
  or maintaining.

## One-time setup (about 10 minutes)

### 1. Create a free GitHub account

If you don't already have one, sign up at [github.com](https://github.com) (free).

If you're going with **Option A** below (GitHub Desktop), you don't need to create
a repository yet — Desktop does that for you when you publish. If you're using
**Option B** (command line), create a new empty **repository** first (the "+" icon
→ "New repository"). Any name is fine, e.g. `wheelie-bin-app`. Public or private
both work.

### 2. Push this project to it

This project has a hidden `.github` folder (that's what makes the auto-build work),
and **GitHub's plain drag-and-drop web upload silently skips hidden folders** — so
dragging the unzipped folder onto the "Upload files" page will look like it worked
but the build pipeline won't actually be there. Use one of these instead:

**Option A — GitHub Desktop (easiest, no typing commands)**

1. Install [GitHub Desktop](https://desktop.github.com/) (free) and sign in with
   your GitHub account.
2. `File` → `Add local repository` → point it at this unzipped `WheelieBinNotifier`
   folder.
3. It'll offer to create a repository from it — confirm.
4. Click `Publish repository` (top bar). Choose public or private, untick nothing,
   publish.

That's it — everything, including the hidden folder, goes up correctly.

**Option B — Command line, if you're comfortable with a terminal**

```bash
git init
git add .
git commit -m "Wheelie bin reminder app"
git branch -M main
git remote add origin https://github.com/<your-username>/<your-repo-name>.git
git push -u origin main
```

### 3. Let GitHub build the APK for you

Pushing to `main` automatically triggers a GitHub Actions workflow
(`.github/workflows/build-apk.yml`) that compiles the app — completely free, using
GitHub's own build servers, no Android Studio required on your end. On the repo
page, click the **Actions** tab and watch it run (takes 3–5 minutes the first time).

### 4. Download and host the APK — for free, on GitHub itself

Once the workflow finishes, go to the **Releases** section of your repo
(`https://github.com/<your-username>/<your-repo-name>/releases`). You'll see a
release called **"latest"** with `WheelieBinNotifier.apk` attached. That's your
permanent, free download link — every time you push a change, this same release
gets refreshed with the new APK.

Open that Releases page **on each phone** (or send the link to yourselves) and tap
the APK to download it.

### 5. Install on your phone

Android will likely ask you to allow installing from this source the first time —
follow the prompt (Settings → allow for "Chrome"/"Files"/whichever app you used to
download it), then tap the downloaded file to install. This is completely normal
for apps installed outside the Play Store and doesn't cost anything.

### 6. Find your UPRN and enter it in the app

Open the app on each phone. You need your household's UPRN once:

1. Go to [findmyaddress.uk](https://www.findmyaddress.uk/search) (a free, official
   public lookup service) and search your postcode.
2. Select your address — it will show you the UPRN.
3. Paste the 12-digit number into the app and tap **Save and start reminders**.

Do this on both your phone and your partner's — same UPRN on both, since you share
a house.

Tap **Check now** any time to see your upcoming collection dates immediately and
confirm it's working.

## Updating the app later

If you ever want to change anything (e.g. move house and need a new UPRN baked in,
or tweak how often it checks), edit the code and push again:

```bash
git add .
git commit -m "Update"
git push
```

A new APK will appear at the same Releases link within a few minutes. Reinstalling
just means downloading and tapping the new APK — your saved UPRN stays put.

## Cost

Free, indefinitely, at this scale:

- **GitHub Actions**: unlimited free minutes on a public repo; 2,000 free
  minutes/month on a private repo (this build uses ~3–5 minutes per run).
- **GitHub Releases**: free file hosting for the APK, no bandwidth limit that you'd
  realistically hit for two people downloading a ~5MB file occasionally.
- **The app itself**: no backend server, so nothing to keep running or paying for.

## Notes on the data source

Newport's bin lookup is provided by a third party (iTouchVision) and identified via
Newport-specific client/council IDs. If Newport City Council changes this system,
the app would need `NewportBinApi.kt` updated to match — everything relevant lives
in that one file.
